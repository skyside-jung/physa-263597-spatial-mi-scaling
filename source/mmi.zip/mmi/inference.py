"""Model-blind finite-size collapse from v0.1 merged profiles.

Inference does not import model definitions, exact Tc, Wolff, or spin configurations.
The analyst must explicitly supply the scaling exponents; no model-specific
critical exponent is inferred from a model name.
"""
import csv, json, math
from pathlib import Path
import numpy as np

ESTIMATORS = {"mi_symmetry_pooled": "MI (symmetrized pooled counts)",
              "mi_pooled": "MI (pooled joint counts)",
              "equal_state_connected": "Equal-state correlation"}

def _read_rows(path):
    with open(path, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

def _write_csv(path, columns, rows):
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=columns); w.writeheader();w.writerows(rows)

def _specs(cfg):
    if 'inference' not in cfg:
        raise ValueError('Protocol must explicitly include inference settings')
    a=cfg['inference']
    if not isinstance(a,dict) or set(a)-{'rho_min','rho_max','rho_points','exponents','estimators','development_sizes','heldout_sizes'}:
        raise ValueError('invalid inference settings')
    low=float(a['rho_min']);high=float(a['rho_max']);n=int(a['rho_points'])
    if not (0<low<high<=0.5 and n>=3): raise ValueError('invalid relative distance grid')
    est=a.get('estimators', list(ESTIMATORS))
    if not est or len(set(est))!=len(est) or any(e not in ESTIMATORS for e in est):raise ValueError('unknown or duplicate estimator')
    ex=a['exponents']
    if not isinstance(ex,dict): raise ValueError('exponents must be a mapping')
    for data_id in cfg['models']:
        vals=ex[data_id] if data_id in ex and isinstance(ex[data_id],dict) else ex
        if set(vals)!=set(est) or any(not math.isfinite(float(v)) or float(v)<0 for v in vals.values()):
            raise ValueError('finite nonnegative exponent required for every estimator and dataset')
    return a, np.linspace(low,high,n),est,ex

def collapse(root, *, require_complete=True):
    root=Path(root)
    cfg=json.loads((root/'protocol.json').read_text(encoding='utf-8'))
    from .workflow import merge
    report=merge(root)  # verifies hash, count integrity, then regenerates all profiles
    if require_complete and report['status']!='COMPLETE':
        raise RuntimeError('Cannot infer critical temperature from PARTIAL experiment')
    a,rhos,estimators,exponents=_specs(cfg)
    sizes=sorted(cfg['sizes']);dev=sorted(a.get('development_sizes',sizes))
    held=sorted(a.get('heldout_sizes',[]))
    if len(dev)<3:raise ValueError('At least 3 development sizes required')
    if set(dev)&set(held) or not set(dev+held)<=set(sizes):raise ValueError('Invalid/disjoint size split')
    if held and len(held)<3:raise ValueError('Heldout needs >=3 independent sizes')
    grps={'development':dev}
    if held:grps['heldout']=held
    rows=_read_rows(root/'merged'/'profiles.csv')
    # Independent run unit = seed. Pooling across seeds for this prototype is
    # NOT equivalent to count pooling across all frames; report explicitly.
    bykey={}
    for row in rows:
        key=(row['model'],int(row['L']),float(row['T']),int(row['seed']))
        bykey.setdefault(key,[]).append(row)
    scores=[];selections=[];warnings=[]
    models=cfg['models'];temps=cfg['temperatures']
    for model in models:
        tempgrid=sorted(float(t) for t in temps[model])
        if len(tempgrid)<3:raise ValueError('At least 3 temperatures required to locate an interior minimum')
        for group,size_set in grps.items():
            for estimator in estimators:
                expmap=exponents[model] if model in exponents and isinstance(exponents[model],dict) else exponents
                x=float(expmap[estimator])
                for t in tempgrid:
                    curves=[]
                    for L in size_set:
                        selected=[key for key in bykey if key[0]==model and key[1]==L and math.isclose(key[2],t,rel_tol=0,abs_tol=1e-10)]
                        if len(selected)!=len(cfg['seeds']):raise RuntimeError(f'Missing seed: {model}, {L}, {t}')
                        sampled=[]
                        for key in selected:
                            ar=sorted(bykey[key],key=lambda row:float(row['rho']))
                            grid=np.array([float(z['rho']) for z in ar]); vals=np.array([float(z[estimator]) for z in ar]);
                            if grid[0]>rhos[0]+1e-12 or grid[-1]<rhos[-1]-1e-12:
                                raise ValueError(f'rho grid not covered at L={L}; choose smaller rho_min or larger L')
                            sampled.append(np.interp(rhos,grid,vals))
                        curves.append(np.mean(sampled,axis=0)*(L**x))
                    arr=np.stack(curves)
                    mean=np.mean(arr,axis=0)
                    # CV is ill-defined at zero mean. Do not silently floor it.
                    if np.any(mean<=0): raise ValueError(f'Nonpositive mean curve: {model} {group} {estimator} T={t}')
                    cv=np.std(arr,axis=0,ddof=0)/mean
                    s=float(np.mean(cv))
                    scores.append(dict(model=model,group=group,estimator=estimator,exponent=x,T=t,score=s,n_sizes=len(size_set),n_seeds=len(cfg['seeds'])))
                local=[z for z in scores if z['model']==model and z['group']==group and z['estimator']==estimator]
                best=min(local,key=lambda z:(z['score'],z['T']))
                at_boundary=(best['T']==min(tempgrid) or best['T']==max(tempgrid))
                selections.append(dict(model=model,group=group,estimator=estimator,exponent=x,T_hat=best['T'],min_score=best['score'],boundary=at_boundary,n_sizes=len(size_set),n_seeds=len(cfg['seeds']),n_temperatures=len(tempgrid)))
                if at_boundary:warnings.append(f'{model}/{group}/{estimator}: minimum at temperature-grid boundary; NOT a validated critical temperature.')
    out=root/'analysis';out.mkdir(exist_ok=True)
    _write_csv(out/'collapse_scores.csv',list(scores[0]),scores)
    _write_csv(out/'selected_temperatures.csv',list(selections[0]),selections)
    summary={'status':'COMPLETE_DIAGNOSTIC_ONLY','source_status':report['status'],'n_jobs':report['completed'],
             'estimators':list(estimators),'fixed_exponents':dict(exponents),'relative_distance_grid':list(map(float,rhos)),
             'score':'mean population-CV across size-rescaled interpolated curves; seed means before collapse',
             'selection_rule':'discrete argmin; lowest T on exact tie','warnings':warnings,
             'limitations':['No uncertainty estimate or bootstrap in v0.2',
                            'Fixed scaling exponents are REQUIRED inputs; model-free exponent inference NOT implemented',
                            'Symmetry-pooled MI physically interpretable only if colour-permutation symmetry justified',
                            'Equal-state correlation is a baseline for symmetric equal-state models, not generic systems',
                            'Each seed profile averaged equally; not pooled raw counts across seeds',
                            'Heldout data (when supplied) get independently scored; do not tune using heldout',
                            'No evidence of superiority from one run / boundary estimates']}
    (out/'inference_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    lines=['# Automated inference report (v0.2)','',
           'Results are diagnostics, **not** a publication-grade accuracy estimate.','',
           '| Model | Subset | Estimator | T_hat | Boundary? | Min score |','|---|---|---|---:|---|---:|']
    for v in selections:
        lines.append(f"| {v['model']} | {v['group']} | {v['estimator']} | {v['T_hat']:.8g} | {v['boundary']} | {v['min_score']:.6g} |")
    lines+=['','## Warnings']+(['- '+w for w in warnings] if warnings else ['- None from this diagnostic.'])
    lines+=['','## Method','MI/C profiles calculated from preserved per-configuration joint counts.',
            'Fixed exponents provided in protocol, scores calculated at common rho points.',
            'Same spin configurations supply all estimators; exact critical temperature not used.',
            'For model-specific physical interpretation and any comparison with Tc, use separate blinded validation.']
    (out/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return summary
