"""Manifest-driven experiment automation. Fail closed on mismatched protocols."""
import csv, hashlib, json, os, shutil, tempfile, zipfile
from pathlib import Path
import numpy as np
from .simulation import simulate
from .models import MODELS
from .information import mi_bits, symmetry_pool, equal_state_connected

def dump(path,obj):
    Path(path).write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False),encoding='utf-8')
def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<18),b''):h.update(b)
    return h.hexdigest()
def writecsv(path,header,rows):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)
def readcfg(path):
    cfg=json.loads(Path(path).read_text(encoding='utf-8'))
    allowed={'experiment_id','models','sizes','temperatures','seeds','burn_sweep_eq','gap_clusters','samples_per_run','distances','analysis','inference','statistics'}
    unknown=set(cfg)-allowed
    if unknown:raise ValueError(f'Unknown protocol keys: {sorted(unknown)}')
    if not cfg.get('experiment_id') or not all(str(c).isalnum() or c in '_-' for c in cfg['experiment_id']):raise ValueError('invalid experiment_id')
    if not cfg['models'] or any(m not in MODELS for m in cfg['models']):raise ValueError('model unknown')
    if len(cfg['models'])!=len(set(cfg['models'])):raise ValueError('duplicate models')
    for key in ('sizes','seeds'):
        if not cfg[key] or len(set(cfg[key]))!=len(cfg[key]):raise ValueError(f'invalid/duplicate {key}')
    for L in cfg['sizes']:
        if not isinstance(L,int) or L<4 or L%2:raise ValueError('sizes must be even integers >=4')
    for m in cfg['models']:
        ts=cfg['temperatures'][m]
        if not ts or any(float(t)<=0 for t in ts) or len(set(ts))!=len(ts):raise ValueError('invalid temperatures')
    for k in ('burn_sweep_eq','gap_clusters','samples_per_run'):
        if cfg[k]<=0:raise ValueError(f'{k} must be positive')
    if 'inference' in cfg:
        from .inference import _specs
        _specs(cfg)
    if 'distances' in cfg and cfg['distances']!='all':raise ValueError('v0.1 requires distances=all')
    return cfg

def jobs(cfg):
    return [dict(model=m,L=L,T=float(t),seed=int(s)) for m in cfg['models'] for L in cfg['sizes'] for t in cfg['temperatures'][m] for s in cfg['seeds']]
def job_id(j): return f"{j['model']}_L{j['L']}_T{j['T']:.12g}_seed{j['seed']}"
def setup(cfg_path,root):
    root=Path(root);cfg=readcfg(cfg_path);root.mkdir(parents=True,exist_ok=True)
    target=root/'protocol.json'
    if target.exists():
        if readcfg(target)!=cfg:raise ValueError('existing output has a DIFFERENT protocol')
    else:dump(target,cfg)
    listed=jobs(cfg);dump(root/'jobs.json',listed)
    (root/'jobs').mkdir(exist_ok=True)
    return len(listed)

def validate_job(folder,j,cfg):
    folder=Path(folder);q=MODELS[j['model']].q
    with (folder/'observables.csv').open(newline='') as f: ob=list(csv.DictReader(f))
    if len(ob)!=cfg['samples_per_run'] or {int(x['sample']) for x in ob}!=set(range(cfg['samples_per_run'])):raise ValueError('observations incomplete')
    with (folder/'joint_counts.csv').open(newline='') as f: cn=list(csv.DictReader(f))
    if len(cn)!=cfg['samples_per_run']*(j['L']//2):raise ValueError('counts incomplete')
    ids=set()
    for x in cn:
        sample=int(x['sample']);r=int(x['r']);ident=(sample,r)
        if ident in ids:raise ValueError('duplicate sample/r')
        ids.add(ident)
        table=np.array([int(x[f'n{i}{k}']) for i in range(q) for k in range(q)])
        if table.sum()!=2*j['L']**2 or (table<0).any():raise ValueError('joint count invalid')
    if ids!={(i,r) for i in range(cfg['samples_per_run']) for r in range(1,j['L']//2+1)}:raise ValueError('missing sample/r')
    return {name:digest(folder/name) for name in ('joint_counts.csv','observables.csv')}

def execute(root,index):
    root=Path(root);cfg=readcfg(root/'protocol.json');listed=jobs(cfg)
    j=listed[int(index)];folder=root/'jobs'/job_id(j)
    if (folder/'DONE.json').exists():
        actual=validate_job(folder,j,cfg); meta=json.loads((folder/'DONE.json').read_text())
        if actual!=meta['sha256']:raise ValueError('checksum mismatch')
        return 'SKIPPED',j
    if folder.exists():raise RuntimeError(f'incomplete job requires inspection: {folder}')
    partial=root/'jobs'/(job_id(j)+'.partial')
    if partial.exists():raise RuntimeError(f'partial results require inspection: {partial}')
    partial.mkdir()
    try:
        counts,obs=simulate(j['model'],j['L'],j['T'],j['seed'],cfg['burn_sweep_eq'],cfg['gap_clusters'],cfg['samples_per_run'])
        q=MODELS[j['model']].q
        fields=['sample','r','rho']+[f'n{i}{k}' for i in range(q) for k in range(q)]
        writecsv(partial/'joint_counts.csv',fields,counts)
        writecsv(partial/'observables.csv',['sample','sweep_eq','cluster_updates','equal_bond_fraction','order','mean_cluster_sites'],obs)
        hashes=validate_job(partial,j,cfg)
        dump(partial/'DONE.json',{'job':j,'protocol_sha256':digest(root/'protocol.json'),'sha256':hashes,'status':'COMPLETE'})
        os.replace(partial,folder)
        return 'COMPLETE',j
    except Exception:
        raise

def status(root):
    root=Path(root);cfg=readcfg(root/'protocol.json');listing=jobs(cfg)
    completed=sum((root/'jobs'/job_id(j)/'DONE.json').exists() for j in listing)
    return {'total':len(listing),'completed':completed,'remaining':len(listing)-completed}

def merge(root):
    root=Path(root);cfg=readcfg(root/'protocol.json');completed=[];missing=[]
    for j in jobs(cfg):
        folder=root/'jobs'/job_id(j)
        if not (folder/'DONE.json').exists():missing.append(job_id(j));continue
        hashes=validate_job(folder,j,cfg);meta=json.loads((folder/'DONE.json').read_text())
        if meta['sha256']!=hashes or meta['protocol_sha256']!=digest(root/'protocol.json'):raise ValueError('tampered job')
        completed.append((j,folder))
    merged=root/'merged';merged.mkdir(exist_ok=True)
    profile=[];basic=[]
    for j,folder in completed:
        q=MODELS[j['model']].q
        tables={}
        with (folder/'joint_counts.csv').open(newline='') as f:
            for x in csv.DictReader(f):
                r=int(x['r']);sample=int(x['sample'])
                table=np.array([[int(x[f'n{i}{k}']) for k in range(q)] for i in range(q)],dtype=np.int64)
                tables.setdefault(r,[]).append((sample,table))
        for r,items in sorted(tables.items()):
            items.sort(key=lambda it:it[0]);pool=sum((x for _,x in items),np.zeros((q,q),dtype=np.int64))
            pooled=mi_bits(pool);sym=mi_bits(symmetry_pool(pool));per=float(np.mean([mi_bits(x) for _,x in items]))
            c=equal_state_connected(pool)
            profile.append([j['model'],j['L'],j['T'],j['seed'],r,r/j['L'],per,pooled,sym,c])
        basic.append([*j.values(),job_id(j)])
    writecsv(merged/'profiles.csv',['model','L','T','seed','r','rho','mi_per_snapshot_mean','mi_pooled','mi_symmetry_pooled','equal_state_connected'],profile)
    writecsv(merged/'completed_jobs.csv',['model','L','T','seed','job_id'],basic)
    report={'status':'COMPLETE' if not missing else 'PARTIAL_NOT_FINAL','completed':len(completed),'total':len(jobs(cfg)),'missing':missing,'note':'Inference is calculated during package/infer for complete v0.2 protocols; symmetry MI only valid under full colour permutation symmetry.'}
    dump(merged/'summary.json',report)
    return report

def package(root):
    root=Path(root); report=merge(root)
    if 'inference' in readcfg(root/'protocol.json') and report['status']=='COMPLETE':
        from .inference import collapse
        collapse(root)
        if 'statistics' in readcfg(root/'protocol.json'):
            from .statistics import analyze
            analyze(root)
    from .diagnostics import run_diagnostics
    if report['status']=='COMPLETE':run_diagnostics(root)
    manifest={str(p.relative_to(root)):digest(p) for p in root.rglob('*') if p.is_file() and p.name!='manifest.json' and p.suffix!='zip'}
    dump(root/'manifest.json',manifest)
    target=root.parent/(root.name+'_results.zip')
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob('*')):
            if p.is_file():z.write(p,arcname=f'{root.name}/{p.relative_to(root)}')
    return target,report
