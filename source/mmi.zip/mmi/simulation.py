"""State generator, with fixed cluster update observation cadence.
Energy observable is equal-neighbour fraction, not physical energy.
"""
import numpy as np
from numba import njit
from .models import MODELS, bond_probability

@njit
def seed_numba(seed):
    np.random.seed(seed)

@njit
def wolff_update(state, prob, q):
    L = state.shape[0]
    y0 = np.random.randint(L); x0 = np.random.randint(L)
    old = state[y0, x0]
    replacement = (old + 1 + np.random.randint(q-1)) % q
    marked = np.zeros((L,L), np.uint8)
    ys = np.empty(L*L, np.int32); xs = np.empty(L*L, np.int32)
    ys[0] = y0; xs[0] = x0; marked[y0,x0] = 1
    head=0; n=1
    while head<n:
        y=ys[head]; x=xs[head]; head+=1
        for d in range(4):
            yy=(y+(1 if d==0 else -1 if d==1 else 0))%L
            xx=(x+(1 if d==2 else -1 if d==3 else 0))%L
            if marked[yy,xx]==0 and state[yy,xx]==old and np.random.random()<prob:
                marked[yy,xx]=1;ys[n]=yy;xs[n]=xx;n+=1
    for i in range(n): state[ys[i], xs[i]]=replacement
    return n

def joint_counts(state, distance, q):
    # Both forward axes; exactly 2*L*L directed ordered pairs per radius.
    arr=state.astype(np.int64)
    a=np.bincount((q*arr+np.roll(arr,-distance,axis=0)).ravel(),minlength=q*q)
    b=np.bincount((q*arr+np.roll(arr,-distance,axis=1)).ravel(),minlength=q*q)
    return (a+b).reshape(q,q)

def simulate(model_name, L, temperature, seed, burn_sweep_eq, gap_clusters, samples, distances=None):
    model=MODELS[model_name];q=model.q
    if L<4 or L%2: raise ValueError('L must be even and >=4')
    seed_numba(int(seed))
    # independent initialization; no hidden model-specific RNG within analysis
    rng=np.random.default_rng(int(seed) + 1009)
    state=rng.integers(0,q,size=(L,L),dtype=np.int8)
    p=bond_probability(model,temperature)
    elapsed=0.0; updates=0
    while elapsed<burn_sweep_eq:
        elapsed+=wolff_update(state,p,q)/(L*L);updates+=1
    if distances is None: distances=range(1,L//2+1)
    counts=[]; observables=[]
    for index in range(samples):
        flip_sites=0
        for _ in range(gap_clusters):
            flip_sites+=wolff_update(state,p,q);updates+=1
        elapsed+=flip_sites/(L*L)
        freqs=np.bincount(state.ravel(),minlength=q)
        order=(q*freqs.max()/state.size-1)/(q-1)
        bonds=float((np.mean(state==np.roll(state,1,0))+np.mean(state==np.roll(state,1,1)))/2)
        observables.append([index,elapsed,updates,bonds,float(order),flip_sites/gap_clusters])
        for r in distances:
            table=joint_counts(state,r,q)
            counts.append([index,r,r/L,*table.ravel().tolist()])
    return counts,observables
