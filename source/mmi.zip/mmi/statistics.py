"""Conservative paired-run bootstrap and finite-size / distance sensitivity.

The unit of replication is the full independent seed (matched across size and T).
No physical Tc or model definitions are used by this analysis.
"""
from collections import defaultdict
from pathlib import Path
import csv, json, math
import numpy as np
from .inference import _specs, _read_rows, _write_csv
from .workflow import merge


def _params(cfg):
    cfg_stat=cfg.get('statistics',{})
    if not isinstance(cfg_stat,dict):raise ValueError('statistics must be an object')
    allowed={'bootstrap_repetitions','bootstrap_seed','distance_windows','leave_one_size_out','minimum_independent_seeds'}
    if set(cfg_stat)-allowed:raise ValueError('unknown statistics keys')
    b=cfg_stat.get('bootstrap_repetitions',400)
    if not isinstance(b,int) or b<1 or b>100000:raise ValueError('bootstrap_repetitions out of range')
    n=cfg_stat.get('minimum_independent_seeds',5)
    if not isinstance(n,int) or n<2:raise ValueError('minimum_independent_seeds >=2')
    s=cfg_stat.get('bootstrap_seed',20261024)
    if not isinstance(s,int):raise ValueError('bootstrap_seed must be int')
    return cfg_stat,b,n,s


def analyze(root):
    root=Path(root)
    cfg=json.loads((root/'protocol.json').read_text(encoding='utf-8'))
    if 'inference' not in cfg:raise ValueError('inference required')
    report=merge(root)
    if report['status']!='COMPLETE':raise RuntimeError('Statistics require complete experiment')
    stat,B,minseeds,bootseed=_params(cfg)
    ai,rhos,estimators,exponents=_specs(cfg)
    seeds=list(map(int,cfg['seeds']))
    sizes=sorted(cfg['sizes'])
    dev=sorted(ai.get('development_sizes',sizes));held=sorted(ai.get('heldout_sizes',[]))
    if len(dev)<3 or (held and len(held)<3) or set(dev)&set(held):raise ValueError('invalid size groups')
    groups={'development':dev}
    if held:groups['heldout']=held
    raw=_read_rows(root/'merged'/'profiles.csv')
    d=defaultdict(list)
    for row in raw:d[(row['model'],int(row['L']),float(row['T']),int(row['seed']))].append(row)
    curves={}
    for key,rows in d.items():
        v=sorted(rows,key=lambda r:float(r['rho']))
        grid=np.array([float(r['rho']) for r in v])
        if len(grid)<2 or np.any(np.diff(grid)<=0):raise ValueError('invalid rho profile')
        curves[key]=(grid,{e:np.array([float(r[e]) for r in v]) for e in estimators})
    windows=[('primary',float(rhos[0]),float(rhos[-1]))]
    for i,w in enumerate(stat.get('distance_windows',[])):
        if not isinstance(w,list) or len(w)!=2:raise ValueError('distance window must be [min,max]')
        a,b=map(float,w)
        if not (0<a<b<=0.5):raise ValueError('invalid distance window')
        windows.append((f'window_{i+1}',a,b))
    # This analysis deliberately reuses the same predefined number of rho points.
    all_scores=[]; selections=[]; boots=[];alerts=[];sensitivity=[]
    if len(seeds)<minseeds:alerts.append(f'Seed count {len(seeds)} < configured minimum {minseeds}; bootstrap intervals are DIAGNOSTIC only.')
    rng=np.random.default_rng(bootseed)
    for model in cfg['models']:
        temperatures=sorted(map(float,cfg['temperatures'][model]));
        if len(temperatures)<3:raise ValueError('Need >=3 T values')
        expmap=exponents.get(model,exponents) if isinstance(exponents,dict) else exponents
        for group,fullsizes in groups.items():
            variants=[('all',fullsizes)]
            if stat.get('leave_one_size_out',True) and len(fullsizes)>3:
                variants += [(f'exclude_L{omit}', [s for s in fullsizes if s!=omit]) for omit in fullsizes]
            for variant,ls in variants:
                if len(ls)<3:continue
                for window,a,b in windows:
                    requested=np.linspace(a,b,len(rhos))
                    for estimator in estimators:
                        exponent=float(expmap[estimator]); data=np.empty((len(seeds),len(temperatures),len(ls),len(requested)),float)
                        for si,seed in enumerate(seeds):
                            for ti,T in enumerate(temperatures):
                                for li,L in enumerate(ls):
                                    key=(model,L,T,seed)
                                    if key not in curves:raise ValueError(f'missing curve {key}')
                                    rho,est=curves[key]
                                    if rho[0]>requested[0]+1e-12 or rho[-1]<requested[-1]-1e-12:
                                        raise ValueError(f'distance range unsupported for {key}, {window}')
                                    data[si,ti,li]=np.interp(requested,rho,est[estimator])*(L**exponent)
                        def calc(indices):
                            values=data[indices].mean(axis=0) # seed-means; same seed resampling for every L,T
                            means=values.mean(axis=1)
                            if np.any(means<=0) or not np.isfinite(means).all():return None
                            sc=(values.std(axis=1,ddof=0)/means).mean(axis=1)
                            return sc if np.isfinite(sc).all() else None
                        point=calc(np.arange(len(seeds)))
                        if point is None:
                            alerts.append(f'Undefined CV: {model}/{group}/{variant}/{window}/{estimator}')
                            continue
                        chosen=int(np.argmin(point)); boundary=chosen in (0,len(temperatures)-1)
                        base=dict(model=model,group=group,variant=variant,window=window,estimator=estimator,exponent=exponent,n_sizes=len(ls),n_seeds=len(seeds))
                        for ti,T in enumerate(temperatures):all_scores.append(dict(**base,T=T,score=float(point[ti])))
                        selected=dict(**base,T_hat=float(temperatures[chosen]),score=float(point[chosen]),boundary=boundary)
                        selections.append(selected)
                        if variant=='all' and window=='primary':
                            if boundary:alerts.append(f'Boundary estimate: {model}/{group}/{estimator}')
                            valid=[]
                            if len(seeds)>=2:
                                for _ in range(B):
                                    res=calc(rng.integers(0,len(seeds),size=len(seeds)))
                                    if res is not None:valid.append(float(temperatures[int(np.argmin(res))]))
                            if valid:
                                lo,hi=np.quantile(valid,[.025,.975])
                                mode=max(sorted(set(valid)),key=lambda x:valid.count(x))
                                boots.append(dict(**base,point_T_hat=selected['T_hat'],boot_mean=float(np.mean(valid)),boot_std=float(np.std(valid,ddof=1)) if len(valid)>1 else 0.,boot_p025=float(lo),boot_p975=float(hi),boot_mode=mode,boundary_fraction=sum(x in (temperatures[0],temperatures[-1]) for x in valid)/len(valid),valid_bootstrap=len(valid),requested_bootstrap=B,interpretation='DIAGNOSTIC_ONLY' if len(seeds)<minseeds or boundary else 'PAIRED_SEED_RESAMPLING_NOT_COVERAGE_VALIDATED'))
                        else:sensitivity.append(selected)
    out=root/'analysis';out.mkdir(exist_ok=True)
    def write(name,rows):
        if rows:_write_csv(out/name,list(rows[0]),rows)
    write('stat_collapse_scores.csv',all_scores)
    write('stat_selected_temperatures.csv',selections)
    write('bootstrap_seed_results.csv',boots)
    write('sensitivity_results.csv',sensitivity)
    result={'status':'COMPLETE_DIAGNOSTIC_ONLY','seed_count':len(seeds),'bootstrap_repetitions':B,'bootstrap_seed':bootseed,'bootstrap_unit':'matched independent seed, all temperatures and lattice sizes together','warnings':alerts,'count':{'scores':len(all_scores),'selections':len(selections),'bootstrap_rows':len(boots),'sensitivity':len(sensitivity)},'limitations':['Discrete temperature grid: quantiles are not continuous parameter confidence limits','Bootstrap across <5 independent runs should not support statistical superiority claims','No autocorrelation/block-bootstrap correction within each seed','No bootstrap bias correction for finite-sample MI estimator','Overlap in uncertainty intervals is not a formal test of methods','Distance-window / leave-one-size results are diagnostics, not independent validation','Existing per-seed MI is averaged across seeds; cross-seed raw count pooling not implemented','No exact Tc used in inference; physical accuracy requires separate evaluation']}
    (out/'statistics_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# v0.3 automated uncertainty and sensitivity report','','**Diagnostic only; not journal-ready confidence intervals.**','','| Model | Group | Estimator | Point T | Bootstrap 2.5% | Bootstrap 97.5% | Warning |','|---|---|---|---:|---:|---:|---|']
    for row in boots:
        flag='boundary or few seeds' if row['interpretation']=='DIAGNOSTIC_ONLY' else 'coverage unvalidated'
        lines.append(f"| {row['model']} | {row['group']} | {row['estimator']} | {row['point_T_hat']:.6g} | {row['boot_p025']:.6g} | {row['boot_p975']:.6g} | {flag} |")
    lines.extend(['','## Warnings']+(['- '+v for v in alerts] if alerts else ['- None from configured checks'])+['','## Method','Resample complete independent seed IDs jointly across size and T; no resampling individual spin pairs.','Leave-one-lattice-size-out requires >=3 remaining lattice sizes; missing tests are not implied successes.'])
    (out/'statistics_report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return result
