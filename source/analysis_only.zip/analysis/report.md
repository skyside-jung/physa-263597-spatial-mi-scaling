# Automated inference report (v0.2)

Results are diagnostics, **not** a publication-grade accuracy estimate.

| Model | Subset | Estimator | T_hat | Boundary? | Min score |
|---|---|---|---:|---|---:|
| ising | development | mi_symmetry_pooled | 2.27 | False | 0.0237006 |
| ising | development | equal_state_connected | 2.27 | False | 0.00853542 |
| ising | heldout | mi_symmetry_pooled | 2.27 | False | 0.0321009 |
| ising | heldout | equal_state_connected | 2.27 | False | 0.0142054 |
| potts3 | development | mi_symmetry_pooled | 0.995 | False | 0.00987459 |
| potts3 | development | equal_state_connected | 0.995 | False | 0.00660063 |
| potts3 | heldout | mi_symmetry_pooled | 0.995 | False | 0.0058508 |
| potts3 | heldout | equal_state_connected | 0.995 | False | 0.00238932 |

## Warnings
- None from this diagnostic.

## Method
MI/C profiles calculated from preserved per-configuration joint counts.
Fixed exponents provided in protocol, scores calculated at common rho points.
Same spin configurations supply all estimators; exact critical temperature not used.
For model-specific physical interpretation and any comparison with Tc, use separate blinded validation.
