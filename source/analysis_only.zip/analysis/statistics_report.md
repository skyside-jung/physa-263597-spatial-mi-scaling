# v0.3 automated uncertainty and sensitivity report

**Diagnostic only; not journal-ready confidence intervals.**

| Model | Group | Estimator | Point T | Bootstrap 2.5% | Bootstrap 97.5% | Warning |
|---|---|---|---:|---:|---:|---|
| ising | development | mi_symmetry_pooled | 2.27 | 2.27 | 2.27 | coverage unvalidated |
| ising | development | equal_state_connected | 2.27 | 2.27 | 2.27 | coverage unvalidated |
| ising | heldout | mi_symmetry_pooled | 2.27 | 2.27 | 2.27 | coverage unvalidated |
| ising | heldout | equal_state_connected | 2.27 | 2.27 | 2.27 | coverage unvalidated |
| potts3 | development | mi_symmetry_pooled | 0.995 | 0.995 | 0.995 | coverage unvalidated |
| potts3 | development | equal_state_connected | 0.995 | 0.995 | 0.995 | coverage unvalidated |
| potts3 | heldout | mi_symmetry_pooled | 0.995 | 0.995 | 0.995 | coverage unvalidated |
| potts3 | heldout | equal_state_connected | 0.995 | 0.995 | 0.995 | coverage unvalidated |

## Warnings
- None from configured checks

## Method
Resample complete independent seed IDs jointly across size and T; no resampling individual spin pairs.
Leave-one-lattice-size-out requires >=3 remaining lattice sizes; missing tests are not implied successes.
