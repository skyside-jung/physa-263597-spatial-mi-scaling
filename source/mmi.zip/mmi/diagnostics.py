"""v0.4 diagnostic baselines. Neither proves equilibration nor model-free applicability.

Integrated auto-correlation times are reported in units of SAVED configurations.
Correlation ratio R=C(L/4)/C(L/2) is not the same as a ratio of MI.
"""
import csv, json, math
from collections import defaultdict
from pathlib import Path
import numpy as np
from .workflow import merge
from .inference import _read_rows, _write_csv

FIELDS=("equal_bond_fraction", "order", "mean_cluster_sites")

def integrated_acf(x):
    """Truncated initial-positive-sequence tau_int; descriptive, not a confidence bound."""
    a=np.asarray(x,dtype=float); n=len(a)
    if n<8 or not np.isfinite(a).all():return dict(n=n,lag1=float('nan'),tau_int=float('nan'),ess=float('nan'),window=0,warning='TOO_SHORT_OR_INVALID')
    a=a-a.mean(); den=float(np.dot(a,a))
    if den<=1e-25:return dict(n=n,lag1=float('nan'),tau_int=float('nan'),ess=float('nan'),window=0,warning='CONSTANT_SERIES')
    maxlag=min(n//4,1000); co=[]
    for lag in range(1,maxlag+1):
        co.append(float(np.dot(a[:-lag],a[lag:])/den))
    # add contiguous positive sequence, capped at first non-positive autocorrelation
    pos=[]
    for v in co:
        if v<=0:break
        pos.append(v)
    tau=max(0.5,0.5+sum(pos)); ess=min(float(n),n/(2*tau))
    warnings=[]
    if len(pos)==maxlag:warnings.append('WINDOW_CAPPED')
    if ess<30:warnings.append('LOW_ESS')
    if n<100:warnings.append('SHORT_CHAIN')
    return dict(n=n,lag1=co[0],tau_int=tau,ess=ess,window=len(pos),warning=';'.join(warnings) or 'OK')

def ratio_profiles(profile_rows):
    """Construct C(L/4)/C(L/2) from identical-configuration correlation estimates.
    Requires L divisible by 4. Each (model,L,T,seed) is independent.
    """
    groups=defaultdict(dict)
    for r in profile_rows:
        key=(r['model'],int(r['L']),float(r['T']),int(r['seed']))
        groups[key][int(r['r'])]=float(r['equal_state_connected'])
    out=[]
    for (model,L,T,seed),by_r in sorted(groups.items()):
        if L%4: continue
        near=by_r.get(L//4); far=by_r.get(L//2)
        valid=(near is not None and far is not None and near>0 and far>0 and math.isfinite(near) and math.isfinite(far))
        out.append(dict(model=model,L=L,T=T,seed=seed,r1=L//4,r2=L//2,C_r1=near,C_r2=far,ratio=near/far if valid else float('nan'),valid=valid))
    return out

def ratio_crossings(ratios):
    """Adjacent size crossings via linear interpolation in T. No extrapolation."""
    values=defaultdict(list)
    for r in ratios:
        if r['valid']:values[(r['model'],int(r['L']),float(r['T']))].append(float(r['ratio']))
    averaged={key:float(np.mean(val)) for key,val in values.items()}
    models=sorted({k[0] for k in averaged});out=[]
    for model in models:
        sizes=sorted({L for m,L,_ in averaged if m==model})
        for L1,L2 in zip(sizes[:-1],sizes[1:]):
            temps=sorted({T for m,l,T in averaged if m==model and l==L1 and (model,L2,T) in averaged})
            crossings=[]
            for a,b in zip(temps[:-1],temps[1:]):
                d0=averaged[(model,L1,a)]-averaged[(model,L2,a)]
                d1=averaged[(model,L1,b)]-averaged[(model,L2,b)]
                if d0==0:crossings.append(a)
                elif d0*d1<0 or d1==0:
                    crossings.append(float(a+(b-a)*(-d0)/(d1-d0)))
            status='NO_CROSSING' if not crossings else ('MULTIPLE_CROSSINGS' if len(crossings)>1 else 'ONE_CROSSING')
            out.append(dict(model=model,L_small=L1,L_large=L2,n_common_T=len(temps),status=status,n_crossings=len(crossings),crossing_T=crossings[0] if len(crossings)==1 else float('nan'),all_crossings=';'.join(f'{v:.12g}' for v in crossings)))
    return out

def run_diagnostics(root):
    root=Path(root)
    report=merge(root)
    if report['status']!='COMPLETE':raise RuntimeError('Diagnostics require all experiment jobs complete')
    cfg=json.loads((root/'protocol.json').read_text(encoding='utf-8'))
    analysis=root/'analysis';analysis.mkdir(exist_ok=True)
    acf=[]
    from .workflow import jobs,job_id
    for j in jobs(cfg):
        path=root/'jobs'/job_id(j)/'observables.csv'
        with path.open(newline='',encoding='utf-8') as fp:rows=list(csv.DictReader(fp))
        for f in FIELDS:
            stat=integrated_acf([float(row[f]) for row in rows])
            acf.append(dict(**j,observable=f,**stat))
    _write_csv(analysis/'autocorrelation_diagnostics.csv',list(acf[0]),acf)
    profile=_read_rows(root/'merged'/'profiles.csv')
    ratio=ratio_profiles(profile)
    if ratio:_write_csv(analysis/'correlation_ratios.csv',list(ratio[0]),ratio)
    crossings=ratio_crossings(ratio)
    if crossings:_write_csv(analysis/'correlation_ratio_crossings.csv',list(crossings[0]),crossings)
    alerts=[f"{a['model']} L={a['L']} T={a['T']} seed={a['seed']} {a['observable']}: {a['warning']}" for a in acf if a['warning']!='OK']
    alerts.extend(f"{c['model']} L={c['L_small']}/{c['L_large']}: {c['status']}" for c in crossings if c['status']!='ONE_CROSSING')
    summary=dict(status='DIAGNOSTIC_ONLY',n_jobs=report['completed'],n_autocorrelation_records=len(acf),n_ratio_records=len(ratio),n_size_pairs=len(crossings),alerts=alerts,
        limitations=['ESS is a truncated positive-ACF estimate from saved configurations only, not proof of stationarity.',
        'Equal-bond fraction is not physical energy; it is proportional to bonds for fixed lattice but has an offset.',
        'Correlation ratio crossing from discrete temperature grid uses linear interpolation, not conventional error bars.',
        'If 0 or multiple crossings, crossing temperature is explicitly undefined.',
        'Correlation ratios only defined for positive nonzero connected correlations and L divisible by 4.',
        'Ratio is the simple C(L/4)/C(L/2) baseline; not a validated replacement for full FSS.',
        'No calibrated confidence intervals or independent cold/hot equilibrium certification.'])
    (analysis/'diagnostics_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    lines=['# v0.4 Autocorrelation and correlation-ratio diagnostics','',f"Jobs verified: {report['completed']}",f"Autocorrelation rows: {len(acf)}",f"Size pairs: {len(crossings)}",'',
           '| Model | Sizes | Crossing status | Crossing T |','|---|---|---|---|']
    for x in crossings:lines.append(f"| {x['model']} | {x['L_small']}-{x['L_large']} | {x['status']} | {x['crossing_T']} |")
    lines+=['','## Warnings']+['- '+s for s in alerts[:60]]+(['- Additional warnings in diagnostics_summary.json'] if len(alerts)>60 else [])
    lines+=['','## Scope']+['- '+s for s in summary['limitations']]
    (analysis/'diagnostics_report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return summary
