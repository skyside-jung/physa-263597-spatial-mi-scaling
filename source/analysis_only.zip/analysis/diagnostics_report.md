# v0.4 Autocorrelation and correlation-ratio diagnostics

Jobs verified: 1170
Autocorrelation rows: 3510
Size pairs: 16

| Model | Sizes | Crossing status | Crossing T |
|---|---|---|---|
| ising | 32-48 | ONE_CROSSING | 2.2690357145095863 |
| ising | 48-64 | ONE_CROSSING | 2.269421202152305 |
| ising | 64-72 | MULTIPLE_CROSSINGS | nan |
| ising | 72-96 | ONE_CROSSING | 2.2699839193793396 |
| ising | 96-104 | ONE_CROSSING | 2.2730084958209593 |
| ising | 104-128 | ONE_CROSSING | 2.264821676211505 |
| ising | 128-144 | ONE_CROSSING | 2.26723740309697 |
| ising | 144-208 | ONE_CROSSING | 2.267821240278903 |
| potts3 | 32-48 | ONE_CROSSING | 0.9953913365922659 |
| potts3 | 48-64 | ONE_CROSSING | 0.9929376868170361 |
| potts3 | 64-72 | ONE_CROSSING | 0.9924499455258429 |
| potts3 | 72-96 | ONE_CROSSING | 0.9944454829562966 |
| potts3 | 96-104 | MULTIPLE_CROSSINGS | nan |
| potts3 | 104-128 | ONE_CROSSING | 0.992352064116165 |
| potts3 | 128-144 | MULTIPLE_CROSSINGS | nan |
| potts3 | 144-208 | MULTIPLE_CROSSINGS | nan |

## Warnings
- potts3 L=208 T=1.015 seed=101 equal_bond_fraction: WINDOW_CAPPED;LOW_ESS
- potts3 L=208 T=1.015 seed=303 equal_bond_fraction: LOW_ESS
- potts3 L=208 T=1.015 seed=404 equal_bond_fraction: LOW_ESS
- potts3 L=208 T=1.015 seed=505 equal_bond_fraction: LOW_ESS
- ising L=64/72: MULTIPLE_CROSSINGS
- potts3 L=96/104: MULTIPLE_CROSSINGS
- potts3 L=128/144: MULTIPLE_CROSSINGS
- potts3 L=144/208: MULTIPLE_CROSSINGS

## Scope
- ESS is a truncated positive-ACF estimate from saved configurations only, not proof of stationarity.
- Equal-bond fraction is not physical energy; it is proportional to bonds for fixed lattice but has an offset.
- Correlation ratio crossing from discrete temperature grid uses linear interpolation, not conventional error bars.
- If 0 or multiple crossings, crossing temperature is explicitly undefined.
- Correlation ratios only defined for positive nonzero connected correlations and L divisible by 4.
- Ratio is the simple C(L/4)/C(L/2) baseline; not a validated replacement for full FSS.
- No calibrated confidence intervals or independent cold/hot equilibrium certification.
