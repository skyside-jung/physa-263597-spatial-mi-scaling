import argparse,json
from .workflow import setup,execute,status,merge,package

def main():
    p=argparse.ArgumentParser(prog='python -m mmi')
    p.add_argument('command',choices=['prepare','run','run-all','status','merge','infer','statistics','diagnostics','package'])
    p.add_argument('--config',default='examples/smoke.json')
    p.add_argument('--root',default='experiment_results')
    p.add_argument('--index',type=int)
    a=p.parse_args()
    if a.command=='prepare':print('prepared',setup(a.config,a.root))
    elif a.command=='run':
        if a.index is None:p.error('--index needed')
        print(execute(a.root,a.index))
    elif a.command=='run-all':
        st=status(a.root)
        for i in range(st['total']):print(i,execute(a.root,i),flush=True)
    elif a.command=='status':print(json.dumps(status(a.root),indent=2))
    elif a.command=='infer':
        from .inference import collapse
        print(json.dumps(collapse(a.root),indent=2))
    elif a.command=='statistics':
        from .statistics import analyze
        print(json.dumps(analyze(a.root),indent=2))
    elif a.command=='diagnostics':
        from .diagnostics import run_diagnostics
        print(json.dumps(run_diagnostics(a.root),indent=2))
    elif a.command=='merge':print(json.dumps(merge(a.root),indent=2))
    elif a.command=='package':
        file,report=package(a.root);print(file);print(json.dumps(report,indent=2))
if __name__=='__main__':main()
