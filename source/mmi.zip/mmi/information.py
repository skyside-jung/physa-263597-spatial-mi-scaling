"""Model-blind estimator, operating only on generic joint frequency tables."""
import numpy as np

def mi_bits(counts):
    n=np.asarray(counts,dtype=float)
    if n.ndim!=2 or n.shape[0]!=n.shape[1] or (n<0).any() or n.sum()<=0:
        raise ValueError('invalid square joint count table')
    p=n/n.sum(); a=p.sum(axis=1); b=p.sum(axis=0)
    denom=np.outer(a,b);mask=p>0
    return float(np.sum(p[mask]*np.log2(p[mask]/denom[mask])))

def symmetry_pool(counts):
    """Average colour relabellings exactly, preserving trace/off-diagonal mass.
    Legitimate only when full permutation symmetry is justified.
    """
    n=np.asarray(counts,dtype=float);q=n.shape[0]
    if n.ndim!=2 or n.shape!=(q,q):raise ValueError('square required')
    ans=np.full((q,q),(n.sum()-np.trace(n))/(q*(q-1)),dtype=float)
    np.fill_diagonal(ans,np.trace(n)/q)
    return ans

def equal_state_connected(counts):
    n=np.asarray(counts,dtype=float);q=n.shape[0]
    return float(np.trace(n)/n.sum()-1/q)
