"""Model-dependent configuration. Analysis never needs these functions."""
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class Model:
    name: str
    q: int
    coupling_factor: float

MODELS = {'ising': Model('ising', 2, 2.0), 'potts3': Model('potts3', 3, 1.0)}

def bond_probability(model: Model, temperature: float) -> float:
    if temperature <= 0: raise ValueError('T must be positive')
    return -math.expm1(-model.coupling_factor / temperature)
